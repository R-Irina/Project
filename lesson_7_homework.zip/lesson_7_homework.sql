--colab/jupyter: https://colab.research.google.com/drive/1j4XdGIU__NYPVpv74vQa9HUOAkxsgUez?usp=sharing

--task1  (lesson7)
-- sqlite3: Сделать тестовый проект с БД (sqlite3, project name: task1_7). 
-- В таблицу table1 записать 1000 строк с случайными значениями (3 колонки, тип int) от 0 до 1000.
-- Далее построить гистограмму распределения этих трех колонок

--task2  (lesson7)
-- oracle: https://leetcode.com/problems/duplicate-emails/
-- с использованием оконной функции
select distinct email 
from (
	select *,
	    row_number() over(partition by email order by id) cnt_post 
	from person) tmp
where cnt_post > 1

-- другой способ
select email
from person
group by email
having count(email) > 1

--task3  (lesson7)
-- oracle: https://leetcode.com/problems/employees-earning-more-than-their-managers/
select
     Employee.name as Employee
from Employee join Employee as Manager
     on Employee.ManagerId = Manager.Id
     and Employee.Salary > Manager.Salary

--task4  (lesson7)
-- oracle: https://leetcode.com/problems/rank-scores/
select id, score,
    dense_rank() over (order by score desc) as d_rank,
from Scores

--task5  (lesson7)
-- oracle: https://leetcode.com/problems/combine-two-tables/
select firstname
       , lastname
       , city
       , state
from person p left join address adr on
p.personId = adr.personId
